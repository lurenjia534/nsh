"""Create a vector comparison diagram from real CI screenshot pixels."""
import base64
from io import BytesIO
import importlib.util
from pathlib import Path
import sys
from xml.sax.saxutils import escape
from PIL import Image

sys.dont_write_bytecode = True
root = Path(__file__).resolve().parent
helper = root / 'capture-comparison.py'
spec = importlib.util.spec_from_file_location('capture_comparison', helper)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
rows = [
    ('macos', 'macOS', 'AppKit / CoreText', 'Missing before; visible after.'),
    ('windows', 'Windows', 'Win32 / DirectWrite', 'Missing before; visible after.'),
    ('linux', 'Linux', 'GTK 4 / Pango', 'Partial line before; full line after.'),
    ('gpui', 'GPUI on Linux', 'GPUI text renderer', 'Partial line before; full line after.'),
    ('ios', 'iOS simulator', 'UIKit / CoreText', 'Visible in both; position changes.'),
    ('android', 'Android emulator *', 'Android / StaticLayout', 'Awaiting visual review.'),
    ('web', 'Web', 'Chrome / browser text', 'Visible in both; position changes.'),
]
height = 150 + len(rows) * 155 + 130
parts = [f'''<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1320" height="{height}" viewBox="0 0 1320 {height}">
<rect width="1320" height="{height}" fill="#f4f6fa"/>
<g font-family="Noto Sans, sans-serif">
<text x="30" y="45" font-size="29" font-weight="700" fill="#0f172a">TextView #447: cross-platform underline comparison</text>
<text x="30" y="82" font-size="18" fill="#536278">11pt font / 15pt line height · system fonts · magnified final-line crops from real CI captures</text>
<text x="368" y="127" font-size="22" font-weight="600" fill="#c62828">Before: fixed 3pt offset</text>
<text x="842" y="127" font-size="22" font-weight="600" fill="#087f5b">After: automatic position</text>''']
for index, (target, title, engine, observation) in enumerate(rows):
    y = 150 + index * 155
    directory = root / target
    if target == 'android' and (root / 'android-retry/after-reported.png').exists():
        directory = root / 'android-retry'
    if target == 'windows' and (root / 'windows-retry/after-reported.png').exists():
        directory = root / 'windows-retry'
    parts.append(f'<rect x="20" y="{y}" width="1280" height="140" rx="12" fill="white" stroke="#dce2eb"/>')
    parts.append(f'<text x="40" y="{y+38}" font-size="22" font-weight="600" fill="#0f172a">{escape(title)}</text>')
    parts.append(f'<text x="40" y="{y+66}" font-size="16" fill="#536278">{escape(engine)}</text>')
    if target == 'android' and (directory / 'after-reported.png').exists():
        observation = 'Visible in both; position changes.'
    parts.append(f'<text x="40" y="{y+99}" font-size="15" fill="#536278">{escape(observation)}</text>')
    for i, variant in enumerate(['before', 'after']):
        path = directory / f'{variant}-reported.png'
        x = 368 + i * 474
        color = '#c62828' if i == 0 else '#087f5b'
        if not path.exists():
            parts.append(f'<text x="{x}" y="{y+70}" font-size="20" fill="#536278">Pending capture</text>')
            continue
        card = module.card(Image.open(path).convert('RGB'))
        scale = card.height / 107
        box = (round(14*scale), round(card.height-31.5*scale), round(132*scale), round(card.height-11*scale))
        crop = card.crop(box)
        ink = crop.convert("L").point(lambda p: 255 if p < 100 else 0).getbbox()
        if ink:
            top = max(0, ink[1] - round(scale))
            crop = crop.crop((0, top, crop.width, crop.height))
        crop.save(directory / f'final-line-{variant}.png')
        buffer = BytesIO(); crop.save(buffer, format='PNG')
        data = base64.b64encode(buffer.getvalue()).decode()
        display_height = 360 * crop.height / crop.width
        parts.append(f'<rect x="{x-8}" y="{y+25}" width="376" height="88" rx="6" fill="white" stroke="{color}" stroke-width="2"/>')
        parts.append(f'<image x="{x}" y="{y+36}" width="360" height="{display_height}" image-rendering="optimizeSpeed" xlink:href="data:image/png;base64,{data}"/>')
footer = 150 + len(rows) * 155
parts.append(f'''<text x="30" y="{footer+30}" font-size="16" fill="#536278">Original screenshot pixels preserved; crops are enlarged without smoothing. Each backend has five before/after cases.</text>
<text x="30" y="{footer+60}" font-size="16" fill="#536278">* Android uses the same CI-only Command::Tokens build workaround in both versions; see REPORT.txt.</text>
<text x="30" y="{footer+90}" font-size="16" fill="#536278">These captures verify the shown system-font case. Visibility before the fix varies by font and backend.</text>
</g></svg>''')
(root / 'cross-platform-summary-en.svg').write_text(''.join(parts))
print(root / 'cross-platform-summary-en.svg')
